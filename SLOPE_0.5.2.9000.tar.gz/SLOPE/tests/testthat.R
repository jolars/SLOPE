library(testthat)
library(SLOPE)

test_check("SLOPE")

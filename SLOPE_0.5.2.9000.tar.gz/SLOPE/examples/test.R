library(SLOPE)

response <- "gaussian"

data <- SLOPE:::randomProblem(n = 20, p = 10, response = response)

fit <- SLOPE(
  data$x,
  data$y,
  family = response,
  scale = FALSE,
  center = TRUE,
  path_length = 100
)
